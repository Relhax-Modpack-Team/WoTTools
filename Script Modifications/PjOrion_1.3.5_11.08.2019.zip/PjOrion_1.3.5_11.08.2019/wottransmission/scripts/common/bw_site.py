'''
The wot-transmission initialization
'''

# WOT-Transmission ------------------------------------------------------------------

from sys import path as syspath
from os import path as ospath
from os import remove

wwt_zipfile = '$WOTTransmission$'
outpath = '$OutPath$'
refreshinterval = $RefreshInterval$
printingsymbolsmode = $PrintingSymbolsMode$

try:
    basepath = wwt_zipfile.replace(ospath.basename(wwt_zipfile),'')
    dcp_zipfile = basepath+'dcpack.zip'
    dis_zipfile = basepath+'dispack.zip'
    syspath.insert(0, basepath)
    syspath.insert(0, dcp_zipfile)
    syspath.insert(0, dcp_zipfile+'/dcpack')    
    syspath.insert(0, dis_zipfile)
    syspath.insert(0, dis_zipfile+'/dispack')     
    syspath.insert(0, wwt_zipfile)
    syspath.insert(0, wwt_zipfile+'/wottransmission')
    from wottransmission.transmitter import orion_transfer_init
    orion_transfer_init(outpath, refreshinterval, printingsymbolsmode)
    remove(outpath + 'bw_site.pyc')
except Exception as E:
    print 'Error: WOT-Transmission in client is not initialized! (%s)' % str(E) 
    import traceback
    traceback.format_exc()


# Load code of the original module --------------------------------------------------

from zipfile import ZipFile
from marshal import loads

with ZipFile('./res/packages/scripts.pkg', 'r') as z:
    with z.open('scripts/common/bw_site.pyc') as f:
        module = loads(f.read()[8:])

exec module in globals()